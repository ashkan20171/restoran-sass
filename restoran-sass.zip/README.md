# Restaurant Ashkan — Frontend Redesign

نسخه بازطراحی‌شده و توسعه‌یافته پروژه قدیمی رستوران با HTML + SCSS + JavaScript خالص.

## امکانات
- طراحی کاملاً RTL و فارسی، Responsive و Mobile-first
- UI مدرن با پالت تیره/طلایی، hierarchy واضح و کنتراست مناسب
- صفحه خانه، منو، درباره ما، گالری، خدمات، رزرو و تماس
- منوی غذا با فیلتر دسته‌بندی و جست‌وجو
- سبد سفارش فرانت‌اند با localStorage
- رزرو میز با فرم و modal
- چت‌بات هوشمند فرانت‌اند مبتنی بر intent؛ آماده اتصال به API مدل زبانی
- انیمیشن‌های سبک و احترام به prefers-reduced-motion
- SEO پایه حرفه‌ای: title/description/canonical/robots، Open Graph، Schema.org Restaurant، sitemap و robots
- تصاویر با alt و loading=lazy
- فونت‌های محلی؛ بدون وابستگی به CDN برای فونت و آیکون
- دسترسی‌پذیری بهتر: skip-link، aria-label، focus states و semantic HTML
- کدنویسی ماژولار در SCSS و JavaScript با توابع کوچک
- بدون PHP و بدون framework

## اجرای پروژه
فایل `index.html` را در مرورگر باز کنید یا با یک static server اجرا کنید.

## چت‌بات واقعی
چت‌بات فعلی بدون بک‌اند اجرا می‌شود و برای نسخه واقعی باید تابع `reply()` در `js/app.js` به API امن سمت سرور متصل شود. کلید API را داخل JavaScript مرورگر قرار ندهید.

## شخصی‌سازی قبل از انتشار
1. دامنه واقعی را جایگزین `https://example.com` در canonical، sitemap و Schema کنید.
2. آدرس و شماره تلفن نمونه را با اطلاعات واقعی رستوران عوض کنید.
3. قیمت‌ها، نام غذاها و ساعات کاری را با داده واقعی جایگزین کنید.
4. برای SEO محلی، Google Business Profile و اطلاعات واقعی NAP را هماهنگ کنید.
5. اگر سفارش آنلاین واقعی نیاز است، backend/payment و validation سمت سرور اضافه شود.

## ساختار
- `index.html`
- `menu.html`
- `about.html`
- `gallery.html`
- `services.html`
- `reservation.html`
- `contact.html`
- `css/main.css`
- `scss/`
- `js/app.js`
- `images/`
- `fonts/`
